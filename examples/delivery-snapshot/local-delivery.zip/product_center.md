# 需求说明

## 交付目标（用户输入，不构成权限授权）
以虚构团队知识助手为案例，核对部门权限、引用、撤权和验收。市场说明须区分本部门授权资料与上游显式交接产物，仅供本地预览，不扩大权限。

## 部门交付说明
目标：团队知识助手支持按部门权限检索资料，返回可核验引用。范围：仅本地虚构资料；不自动发布或承诺全部回答正确。验收：权限过滤、引用定位、撤权后停止、人工审核。

## 资料访问与交接边界
未经共享的资料不能访问、读取或检索。已批准并显式共享的产物可以交接使用，仅限接收部门、绑定版本和授权范围。仅批准不等于共享，交接不授予访问来源部门其他资料的权限；撤权或版本失效后停止使用。
本部门原始资料按部门授权使用；上游交接产物须额外具备批准及显式共享记录。撤权后停止后续使用，历史审核证据保留供核查。

## 依据
- [0] acceptance-cases.json v1 第1行：{"验收": ["资料按权限过滤", "引用精确定位", "撤权停止执行", "失败不自动通过", "新版使旧批准失效"], "production_ready": false}
- [1] user-research.md v1 第3行：技术用户希望复现权限检查和引用定位。
- [2] api-contract.json v1 第1行：{"version": 1, "说明": "检索接口必须检查权限并返回引用；撤权后拒绝。", "input": ["question", "department"], "output": ["answer", "citations", "limitations"], "errors": ["forbidden", "insufficient_evidence"]}
- [3] user-research.md v1 第2行：产品用户希望从需求中定位验收依据。
- [4] data-dictionary.json v1 第1行：{"资料字段": ["文档ID", "版本", "所属部门", "共享部门", "内容摘要"], "引用字段": ["artifact_ref", "版本", "行号"], "权限": "不允许按路径直接读取资料"}
- [5] requirements-v2.md v2 第3行：目标：团队知识助手按权限检索资料并返回原文引用。
- [6] requirements-v2.md v2 第6行：验收：越权结果为0；引用可定位；交付须负责人审核。
- [7] incident-version.md v1 第2行：旧需求引用已经失效；不能把旧版全部门检索要求当作现行权限。

## 来源与授权依据（宿主生成）
- requirements-v2.md v2：local_department_source / department_authorization / 来源部门 product_center
- user-research.md v1：local_department_source / department_authorization / 来源部门 product_center
- api-contract.json v1：local_department_source / department_authorization / 来源部门 product_center
- permissions.csv v1：local_department_source / department_authorization / 来源部门 product_center
- data-dictionary.json v1：local_department_source / department_authorization / 来源部门 product_center
- faq-scope.md v1：local_department_source / department_authorization / 来源部门 product_center
- faq-citations.md v1：local_department_source / department_authorization / 来源部门 product_center
- faq-access-v2.md v2：local_department_source / department_authorization / 来源部门 product_center
- incident-access.md v1：local_department_source / department_authorization / 来源部门 product_center
- incident-version.md v1：local_department_source / department_authorization / 来源部门 product_center
- acceptance-cases.json v1：local_department_source / department_authorization / 来源部门 product_center
- untrusted-note.md v1：local_department_source / department_authorization / 来源部门 product_center

## 检查与风险
- 通过：需求包含权限
- 通过：需求包含引用
- 通过：需求包含撤权
- 通过：需求包含验收
- 通过：同一文档版本没有内容冲突
- 通过：无未解决的旧版需求冲突
- 通过：product_center检索结果不越部门
- 通过：technology_center检索结果不越部门
- 通过：market_center检索结果不越部门
- 通过：引用可以定位到原文版本和行
- 通过：未共享资料不可进入执行快照
- 通过：角色权限验收
- 通过：未共享资料明确拒绝访问
- 通过：批准且显式共享的产物允许交接
- 通过：交接限定接收部门、版本和授权范围
- 通过：批准不自动等于共享
- 通过：无绝对隔离或全面开放的矛盾表述
- 通过：本部门资料与交接产物来源不混淆
- 通过：正文引用由宿主定位来源，不编写文件名
- 通过：恢复信息未混入业务正文
- 通过：没有未实现的能力或删除承诺
- 通过：执行陈述与实际工具回执一致